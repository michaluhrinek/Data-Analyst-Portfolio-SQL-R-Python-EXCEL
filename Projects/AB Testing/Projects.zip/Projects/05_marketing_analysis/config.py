"""Configuration for Project 5 — Marketing Analysis"""

# ─── DATA SOURCE ─────────────────────────────────────────────────────────────
USE_SYNTHETIC = True
INPUT_FILE = None
# If using your own CSV, columns required:
#   customer_id, order_date, order_value, channel

# ─── SYNTHETIC DATA PARAMETERS ───────────────────────────────────────────────
N_CUSTOMERS = 3000
ORDERS_PER_CUSTOMER_LAMBDA = 2.5  # average orders per customer
START_DATE = "2024-01-01"
END_DATE = "2024-12-31"
CHANNELS = ["Organic Search", "Paid Search", "Social", "Email", "Referral"]
CHANNEL_WEIGHTS = [0.30, 0.25, 0.20, 0.15, 0.10]
# Cost per acquired customer by channel (used for CAC calculation)
CHANNEL_CAC = {
    "Organic Search": 5,
    "Paid Search":   25,
    "Social":        18,
    "Email":          3,
    "Referral":      10,
}
RANDOM_SEED = 42

# ─── ANALYSIS PARAMETERS ─────────────────────────────────────────────────────
N_CLUSTERS = 4
ANALYSIS_DATE = "2024-12-31"   # 'today' for RFM calculation

# ─── FILE PATHS ──────────────────────────────────────────────────────────────
RAW_DATA_PATH = "data/raw_data.csv"
CUSTOMERS_PATH = "data/customers.csv"
OUTPUT_DIR = "outputs"
