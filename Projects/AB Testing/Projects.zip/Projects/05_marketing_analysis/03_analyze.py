"""
03_analyze.py — Marketing analytics: clustering, cohort, attribution.

Three analyses:
  1. K-means clustering on RFM features (alternative to rule-based segments)
  2. Cohort retention: how do customers from each signup month behave?
  3. Channel attribution: revenue, CAC, ROI by acquisition channel
"""

import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).parent))
import config


def run_clustering(customers: pd.DataFrame) -> pd.DataFrame:
    """K-means on standardized RFM."""
    features = customers[["recency_days", "frequency", "monetary"]].copy()
    # Log-transform monetary and frequency to reduce skew
    features["monetary"] = np.log1p(features["monetary"])
    features["frequency"] = np.log1p(features["frequency"])

    scaler = StandardScaler()
    X = scaler.fit_transform(features)

    km = KMeans(n_clusters=config.N_CLUSTERS,
                random_state=config.RANDOM_SEED, n_init=10)
    customers["cluster"] = km.fit_predict(X)
    return customers


def build_cohort_matrix(orders: pd.DataFrame) -> pd.DataFrame:
    """Rows: acquisition month. Columns: months since acquisition. Values: % active.

    Retention % = (unique customers from cohort active in period N) / (cohort size)
    where cohort size = total unique customers acquired in that month.
    """
    orders = orders.copy()
    orders["order_month"] = orders["order_date"].dt.to_period("M")
    orders["cohort_month"] = orders["acquisition_date"].dt.to_period("M")

    # Cohort size: total unique customers per acquisition month
    cohort_sizes = orders.groupby("cohort_month")["customer_id"].nunique()

    # Active customers per (cohort, period)
    active = (orders.groupby(["cohort_month", "order_month"])["customer_id"]
              .nunique().reset_index())
    active["period_number"] = ((active["order_month"] - active["cohort_month"])
                               .apply(lambda x: x.n))

    cohort_pivot = active.pivot_table(index="cohort_month",
                                      columns="period_number",
                                      values="customer_id")

    # Divide each row by its cohort size (not by month-0 count)
    retention = cohort_pivot.divide(cohort_sizes, axis=0)
    # Clip to [0, 1] for display sanity
    retention = retention.clip(0, 1)
    return retention


def channel_attribution(customers: pd.DataFrame) -> pd.DataFrame:
    """Revenue, CAC, ROI by channel."""
    attr = customers.groupby("channel").agg(
        customers=("customer_id", "count"),
        total_revenue=("monetary", "sum"),
        avg_revenue_per_customer=("monetary", "mean"),
        avg_frequency=("frequency", "mean"),
    ).reset_index()
    attr["cac"] = attr["channel"].map(config.CHANNEL_CAC)
    attr["total_cac_spend"] = attr["customers"] * attr["cac"]
    attr["roi"] = (attr["total_revenue"] - attr["total_cac_spend"]) / attr["total_cac_spend"]
    attr = attr.sort_values("roi", ascending=False).reset_index(drop=True)
    return attr


def main():
    orders = pd.read_csv(config.RAW_DATA_PATH,
                         parse_dates=["order_date", "acquisition_date"])
    customers = pd.read_csv(config.CUSTOMERS_PATH,
                            parse_dates=["acquisition_date"])

    # ── 1. Clustering ────────────────────────────────────────────────────
    customers = run_clustering(customers)
    print(f"\nK-means clusters ({config.N_CLUSTERS}):")
    for c in sorted(customers["cluster"].unique()):
        sub = customers[customers["cluster"] == c]
        print(f"  Cluster {c}: {len(sub):,} customers | "
              f"avg recency={sub['recency_days'].mean():.0f}d, "
              f"avg freq={sub['frequency'].mean():.1f}, "
              f"avg spend=${sub['monetary'].mean():.0f}")

    # ── 2. Cohorts ───────────────────────────────────────────────────────
    cohort_retention = build_cohort_matrix(orders)
    print(f"\nCohort retention matrix shape: {cohort_retention.shape}")

    # ── 3. Channel attribution ───────────────────────────────────────────
    attribution = channel_attribution(customers)
    print(f"\nChannel attribution:")
    print(attribution[["channel", "customers", "total_revenue", "cac", "roi"]]
          .to_string(index=False))

    # ── Save artifacts ───────────────────────────────────────────────────
    Path(config.OUTPUT_DIR).mkdir(exist_ok=True)
    customers.to_csv(config.CUSTOMERS_PATH, index=False)
    cohort_retention.to_csv("data/cohort_retention.csv")
    attribution.to_csv("data/channel_attribution.csv", index=False)

    results = {
        "n_customers": int(len(customers)),
        "n_clusters": config.N_CLUSTERS,
        "segments": customers["segment"].value_counts().to_dict(),
        "best_channel_by_roi": attribution.iloc[0]["channel"],
        "worst_channel_by_roi": attribution.iloc[-1]["channel"],
        "best_roi": float(attribution.iloc[0]["roi"]),
        "worst_roi": float(attribution.iloc[-1]["roi"]),
    }
    with open(Path(config.OUTPUT_DIR) / "results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved → {config.OUTPUT_DIR}/results.json")


if __name__ == "__main__":
    main()
