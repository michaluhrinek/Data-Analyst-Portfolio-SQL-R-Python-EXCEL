"""
01_get_data.py — Generate synthetic e-commerce transaction data.

Each customer has:
  - acquisition_channel (driving CAC)
  - acquisition_date (drives cohort)
  - multiple orders over time (drives RFM)

Outputs:
  - data/raw_data.csv  (one row per order)
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def generate_synthetic_orders() -> pd.DataFrame:
    rng = np.random.default_rng(seed=config.RANDOM_SEED)

    start = pd.Timestamp(config.START_DATE)
    end = pd.Timestamp(config.END_DATE)
    days = (end - start).days

    rows = []
    for i in range(config.N_CUSTOMERS):
        cust_id = f"CUST-{i:05d}"
        channel = rng.choice(config.CHANNELS, p=config.CHANNEL_WEIGHTS)

        # When did they first appear? Uniform across the period.
        acq_offset = rng.integers(0, days - 30)
        acq_date = start + pd.Timedelta(days=int(acq_offset))

        # How many orders? Poisson-distributed, channel influences activity.
        channel_multiplier = {
            "Email": 1.6, "Referral": 1.3, "Organic Search": 1.1,
            "Paid Search": 0.9, "Social": 0.7,
        }[channel]
        n_orders = max(1, int(rng.poisson(
            config.ORDERS_PER_CUSTOMER_LAMBDA * channel_multiplier)))

        # Spread the orders across the remaining time after acquisition
        remaining_days = (end - acq_date).days
        if remaining_days < 1:
            continue
        for _ in range(n_orders):
            order_offset = rng.integers(0, remaining_days)
            order_date = acq_date + pd.Timedelta(days=int(order_offset))
            order_value = float(rng.gamma(shape=3.0, scale=25))  # ~$75 avg
            rows.append({
                "customer_id": cust_id,
                "order_date": order_date,
                "order_value": round(order_value, 2),
                "channel": channel,
                "acquisition_date": acq_date,
            })

    df = pd.DataFrame(rows)
    df = df.sort_values(["customer_id", "order_date"]).reset_index(drop=True)
    print(f"  → generated {len(df):,} orders from "
          f"{df['customer_id'].nunique():,} customers")
    return df


def load_user_file(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"customer_id", "order_date", "order_value", "channel"}
    if not required.issubset(df.columns):
        raise ValueError(f"Missing required columns. Expected {required}")
    df["order_date"] = pd.to_datetime(df["order_date"])
    df = df.sort_values(["customer_id", "order_date"]).reset_index(drop=True)
    # Derive acquisition date from first order if absent
    if "acquisition_date" not in df.columns:
        first = df.groupby("customer_id")["order_date"].min().rename("acquisition_date")
        df = df.merge(first, on="customer_id")
    else:
        df["acquisition_date"] = pd.to_datetime(df["acquisition_date"])
    print(f"  → loaded {len(df):,} orders from "
          f"{df['customer_id'].nunique():,} customers")
    return df


def main():
    Path("data").mkdir(exist_ok=True)
    if config.INPUT_FILE:
        df = load_user_file(config.INPUT_FILE)
    else:
        df = generate_synthetic_orders()
    df.to_csv(config.RAW_DATA_PATH, index=False)
    print(f"Saved → {config.RAW_DATA_PATH}")


if __name__ == "__main__":
    main()
