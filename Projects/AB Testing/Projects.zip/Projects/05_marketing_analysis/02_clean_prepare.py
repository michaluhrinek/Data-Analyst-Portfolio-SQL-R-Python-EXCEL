"""
02_clean_prepare.py — Compute customer-level RFM features.

RFM is the foundational marketing analytics framework:
  - Recency:   how recently did they purchase?
  - Frequency: how often do they purchase?
  - Monetary:  how much do they spend?

We score each customer 1-5 on each dimension, then concatenate into an
RFM score (e.g., "555" = best customers, "111" = lost customers).
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def main():
    df = pd.read_csv(config.RAW_DATA_PATH, parse_dates=["order_date",
                                                         "acquisition_date"])
    print(f"Loaded {len(df):,} orders")

    today = pd.Timestamp(config.ANALYSIS_DATE)

    # Customer-level aggregates
    customers = df.groupby("customer_id").agg(
        recency_days=("order_date", lambda d: (today - d.max()).days),
        frequency=("order_date", "count"),
        monetary=("order_value", "sum"),
        avg_order_value=("order_value", "mean"),
        channel=("channel", "first"),
        acquisition_date=("acquisition_date", "first"),
    ).reset_index()
    customers["cohort_month"] = customers["acquisition_date"].dt.to_period("M").astype(str)

    # Score each dimension 1-5 (5 = best)
    # Recency: lower is better, so invert
    customers["R"] = pd.qcut(customers["recency_days"].rank(method="first"),
                              5, labels=[5, 4, 3, 2, 1]).astype(int)
    customers["F"] = pd.qcut(customers["frequency"].rank(method="first"),
                              5, labels=[1, 2, 3, 4, 5]).astype(int)
    customers["M"] = pd.qcut(customers["monetary"].rank(method="first"),
                              5, labels=[1, 2, 3, 4, 5]).astype(int)
    customers["RFM_score"] = (customers["R"].astype(str)
                              + customers["F"].astype(str)
                              + customers["M"].astype(str))

    # Segment names from R+F+M sum
    def label_segment(row):
        total = row["R"] + row["F"] + row["M"]
        if total >= 13: return "Champions"
        if total >= 10: return "Loyal"
        if total >= 7:  return "Potential"
        if total >= 5:  return "At Risk"
        return "Lost"
    customers["segment"] = customers.apply(label_segment, axis=1)

    seg_counts = customers["segment"].value_counts().to_dict()
    print(f"Customer segments:")
    for s, c in seg_counts.items():
        print(f"  {s:12} {c:,}")

    customers.to_csv(config.CUSTOMERS_PATH, index=False)
    print(f"Saved → {config.CUSTOMERS_PATH}")


if __name__ == "__main__":
    main()
