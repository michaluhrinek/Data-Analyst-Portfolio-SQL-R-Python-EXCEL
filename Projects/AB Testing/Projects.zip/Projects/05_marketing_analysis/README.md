# Project 5 — Marketing Analysis

**Question:** Where should we focus our marketing effort?

## What you'll learn

- **RFM segmentation** — grouping customers by Recency, Frequency, Monetary value
- **K-means clustering** — finding natural groups in customer behavior
- **Cohort analysis** — how customers acquired in different months behave over time
- **Channel attribution** — which marketing channel drives the most value
- Building a multi-faceted analytics report

## What this project does

1. Generates 12 months of synthetic e-commerce data: customers, orders, channels
2. Computes RFM scores and segments customers
3. Runs K-means clustering on RFM features
4. Builds a cohort retention matrix (rows: signup month, cols: months since signup)
5. Calculates channel attribution (revenue and CAC by channel)
6. Produces 4 charts and a comprehensive written report

## How to run

```bash
pip install -r requirements.txt
python run_all.py
```

## Using your own data

Edit `config.py`:

```python
USE_SYNTHETIC = False
INPUT_FILE = "data/my_transactions.csv"
```

Your CSV needs columns: `customer_id`, `order_date`, `order_value`, `channel` (the marketing channel that acquired the customer).

## Output

After running, check `outputs/`:
- `rfm_segments.png` — segment sizes and revenue breakdown
- `customer_clusters.png` — K-means clusters in RFM space
- `cohort_retention.png` — heat map of retention over time
- `channel_attribution.png` — revenue, CAC, and ROI by channel
- `report.md` — full written analysis
