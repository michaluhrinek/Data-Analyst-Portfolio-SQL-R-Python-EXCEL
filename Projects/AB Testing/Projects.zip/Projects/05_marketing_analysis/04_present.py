"""04_present.py — 4 charts + comprehensive report for marketing project."""

import sys
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config

PALETTE = ["#0B2545", "#13315C", "#0E7C7B", "#5EEAD4", "#B85042"]


def make_segments_chart(customers: pd.DataFrame, out_path: Path):
    seg_order = ["Champions", "Loyal", "Potential", "At Risk", "Lost"]
    seg_data = customers.groupby("segment").agg(
        customers=("customer_id", "count"),
        revenue=("monetary", "sum"),
    ).reindex(seg_order).fillna(0)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    ax1.bar(seg_data.index, seg_data["customers"], color=PALETTE)
    ax1.set_title("Customers by RFM segment")
    ax1.set_ylabel("Number of customers")
    for i, v in enumerate(seg_data["customers"]):
        ax1.text(i, v + 5, f"{int(v)}", ha="center", fontweight="bold")
    ax1.tick_params(axis="x", rotation=20)
    ax1.grid(axis="y", alpha=0.3)

    ax2.bar(seg_data.index, seg_data["revenue"], color=PALETTE)
    ax2.set_title("Revenue by RFM segment")
    ax2.set_ylabel("Total revenue ($)")
    for i, v in enumerate(seg_data["revenue"]):
        ax2.text(i, v + seg_data["revenue"].max() * 0.01,
                 f"${int(v):,}", ha="center", fontweight="bold", fontsize=9)
    ax2.tick_params(axis="x", rotation=20)
    ax2.grid(axis="y", alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_clusters_chart(customers: pd.DataFrame, out_path: Path):
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    # Frequency vs Monetary, colored by cluster
    for c in sorted(customers["cluster"].unique()):
        sub = customers[customers["cluster"] == c]
        axes[0].scatter(sub["frequency"], sub["monetary"],
                        c=PALETTE[c % len(PALETTE)],
                        s=15, alpha=0.6, label=f"Cluster {c}")
    axes[0].set_xlabel("Frequency (orders)")
    axes[0].set_ylabel("Monetary value ($)")
    axes[0].set_title("Clusters: frequency × monetary")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    # Recency vs Monetary
    for c in sorted(customers["cluster"].unique()):
        sub = customers[customers["cluster"] == c]
        axes[1].scatter(sub["recency_days"], sub["monetary"],
                        c=PALETTE[c % len(PALETTE)],
                        s=15, alpha=0.6, label=f"Cluster {c}")
    axes[1].set_xlabel("Recency (days since last order)")
    axes[1].set_ylabel("Monetary value ($)")
    axes[1].set_title("Clusters: recency × monetary")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_cohort_chart(out_path: Path):
    cohort = pd.read_csv("data/cohort_retention.csv", index_col=0)

    fig, ax = plt.subplots(figsize=(13, 6))
    sns.heatmap(cohort * 100, annot=True, fmt=".0f", cmap="YlGnBu",
                cbar_kws={"label": "% retained"}, ax=ax)
    ax.set_title("Cohort retention — % of customers active in each period")
    ax.set_xlabel("Months since acquisition")
    ax.set_ylabel("Acquisition month")
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_attribution_chart(out_path: Path):
    attr = pd.read_csv("data/channel_attribution.csv")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    # Revenue by channel
    ax1.barh(attr["channel"][::-1], attr["total_revenue"][::-1],
             color="#0E7C7B")
    ax1.set_title("Total revenue by channel")
    ax1.set_xlabel("Revenue ($)")
    for i, v in enumerate(attr["total_revenue"][::-1]):
        ax1.text(v, i, f"  ${int(v):,}", va="center", fontsize=9)
    ax1.grid(axis="x", alpha=0.3)

    # ROI by channel
    colors = ["#0E7C7B" if r > 0 else "#B85042" for r in attr["roi"][::-1]]
    ax2.barh(attr["channel"][::-1], attr["roi"][::-1], color=colors)
    ax2.axvline(0, color="#999", lw=1)
    ax2.set_title("Return on acquisition spend by channel")
    ax2.set_xlabel("ROI = (Revenue − CAC) / CAC")
    for i, v in enumerate(attr["roi"][::-1]):
        ax2.text(v, i, f"  {v:+.1f}x", va="center", fontsize=9, fontweight="bold")
    ax2.grid(axis="x", alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def write_report(results: dict, out_path: Path):
    attr = pd.read_csv("data/channel_attribution.csv")

    report = f"""# Marketing Analysis Report

## At a glance

- Analyzed **{results['n_customers']:,}** customers across {len(attr)} acquisition channels.
- Highest-ROI channel: **{results['best_channel_by_roi']}** ({results['best_roi']:.1f}x return).
- Lowest-ROI channel:  **{results['worst_channel_by_roi']}** ({results['worst_roi']:.1f}x return).

---

## 1. RFM segmentation

| Segment | What it means | Strategy |
|---------|---------------|----------|
| **Champions** | Best customers (recent, frequent, high spend) | VIP treatment, advocacy programs, early access |
| **Loyal**     | Strong customers, slightly less active | Cross-sell, upsell, loyalty rewards |
| **Potential** | Promising but not yet loyal | Engagement campaigns, education |
| **At Risk**   | Used to be active, now drifting | Win-back offers, personalized outreach |
| **Lost**      | Disengaged, likely churned | Last-chance offers; otherwise stop spending on them |

Counts:

"""
    for seg, count in sorted(results["segments"].items(),
                              key=lambda x: -x[1]):
        report += f"- **{seg}**: {count:,} customers\n"

    report += f"""

See `rfm_segments.png` for the visual.

---

## 2. K-means clustering

We also ran K-means with {results['n_clusters']} clusters on the same RFM features. Where RFM segments are based on fixed rules (Champions, Loyal, etc.), clusters are discovered from the data itself.

**Why use both?**
- RFM segments are easy to explain to non-technical stakeholders.
- Clusters reveal patterns you might not have thought to look for.

See `customer_clusters.png` for the visual.

---

## 3. Cohort retention

A cohort is a group of customers acquired in the same month. Tracking how each cohort behaves over time reveals:

- Whether retention is improving (newer cohorts retain better) or declining (newer cohorts retain worse).
- Whether there's a typical "drop-off month" you need to address.
- Seasonal effects (cohorts acquired in promotional months may behave differently).

See `cohort_retention.png` for the heat map.

---

## 4. Channel attribution

| Channel | Customers | Revenue | CAC | ROI |
|---------|-----------|---------|-----|-----|
"""
    for _, row in attr.iterrows():
        report += (f"| {row['channel']} | {row['customers']:,} | "
                   f"${row['total_revenue']:,.0f} | ${row['cac']:.0f} | "
                   f"{row['roi']:+.1f}x |\n")

    report += f"""

**Practical reading:**

- **High ROI + high volume** → double down on spend.
- **High ROI + low volume**  → can we scale this channel? What's the ceiling?
- **Low ROI + high volume**  → it's expensive but it's our primary acquisition source. Optimize CAC.
- **Low ROI + low volume**   → consider cutting.

See `channel_attribution.png` for the visual.

---

## Recommended next actions

1. **Concentrate retention spend on "At Risk" segment** — they generated revenue once; they're worth saving.
2. **Re-evaluate {results['worst_channel_by_roi']}** — currently the weakest ROI; either reduce spend or test optimizations.
3. **Build a churn model on this dataset** (see Project 4) so you can target retention at the customer level, not just the segment level.
4. **A/B test interventions** (see Project 2) — without controlled tests you'll never know if your retention spend actually retained anyone.

---

## How this connects to the other projects

This is the synthesis layer. Marketing analytics tells you *where the opportunity is*. Churn prediction tells you *who is at risk*. Revenue prediction tells you *how much each opportunity is worth*. A/B testing tells you *whether your intervention actually worked*. Hypothesis testing is the underlying math that makes all of the above defensible.
"""
    out_path.write_text(report, encoding="utf-8")
    print(f"Saved → {out_path}")


def main():
    out_dir = Path(config.OUTPUT_DIR)
    out_dir.mkdir(exist_ok=True)

    customers = pd.read_csv(config.CUSTOMERS_PATH)
    with open(out_dir / "results.json") as f:
        results = json.load(f)

    make_segments_chart(customers, out_dir / "rfm_segments.png")
    make_clusters_chart(customers, out_dir / "customer_clusters.png")
    make_cohort_chart(out_dir / "cohort_retention.png")
    make_attribution_chart(out_dir / "channel_attribution.png")
    write_report(results, out_dir / "report.md")
    print("\nDone. Open the outputs/ folder.")


if __name__ == "__main__":
    main()
