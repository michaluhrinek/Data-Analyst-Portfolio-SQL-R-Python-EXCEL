"""
01_get_data.py — Generate synthetic daily sales or load real data.

Outputs:
  - data/raw_data.csv  (date, revenue)
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def generate_synthetic_sales() -> pd.DataFrame:
    rng = np.random.default_rng(seed=config.RANDOM_SEED)
    dates = pd.date_range(config.START_DATE, config.END_DATE, freq="D")
    n = len(dates)

    # Trend + weekly seasonality + noise + occasional bumps
    trend = config.BASELINE + np.arange(n) * config.GROWTH_PER_DAY
    weekly = config.WEEKLY_AMPLITUDE * np.sin(2 * np.pi * np.arange(n) / 7)
    weekend_boost = np.where(pd.Series(dates).dt.dayofweek.isin([5, 6]),
                             150, 0)
    noise = rng.normal(0, config.NOISE_STD, size=n)

    # A few promotional spikes
    spikes = np.zeros(n)
    spike_days = rng.choice(n, size=15, replace=False)
    spikes[spike_days] = rng.uniform(300, 700, size=15)

    revenue = trend + weekly + weekend_boost + noise + spikes
    revenue = np.clip(revenue, 0, None)  # no negative revenue

    df = pd.DataFrame({"date": dates, "revenue": revenue})
    print(f"  → generated {len(df):,} days of synthetic sales")
    return df


def load_user_file(path: str) -> pd.DataFrame:
    print(f"Loading user data from {path} ...")
    df = pd.read_csv(path)
    df = df[[config.DATE_COLUMN, config.TARGET_COLUMN]].rename(
        columns={config.DATE_COLUMN: "date",
                 config.TARGET_COLUMN: "revenue"}
    )
    df["date"] = pd.to_datetime(df["date"])
    df = df.dropna().sort_values("date").reset_index(drop=True)
    print(f"  → loaded {len(df):,} rows")
    return df


def main():
    Path("data").mkdir(exist_ok=True)
    if config.INPUT_FILE:
        df = load_user_file(config.INPUT_FILE)
    else:
        df = generate_synthetic_sales()
    df.to_csv(config.RAW_DATA_PATH, index=False)
    print(f"Saved → {config.RAW_DATA_PATH}")


if __name__ == "__main__":
    main()
