# Project 3 — Revenue / Volume Prediction

**Question:** How much revenue (or ticket volume, or any continuous outcome) will the next period bring?

## What you'll learn

- How to frame a forecasting problem as supervised learning
- Feature engineering for time series (lags, rolling windows, calendar features)
- Train/test splitting *for time series* (no shuffling — that's data leakage)
- Gradient-boosted trees (LightGBM) for tabular regression
- Evaluating with MAE, RMSE, MAPE, and a naive baseline

## What this project does

1. Generates 3 years of synthetic daily sales data with realistic weekly seasonality, growth trend, holidays effects, and noise (or loads your CSV)
2. Engineers calendar + lag + rolling-window features
3. Trains a LightGBM regressor on the first 80% of time
4. Evaluates on the last 20%
5. Forecasts the next 30 days
6. Produces a chart and a written report

## How to run

```bash
pip install -r requirements.txt
python run_all.py
```

## Using your own data

Edit `config.py`:

```python
USE_SYNTHETIC = False
INPUT_FILE = "data/my_sales.csv"
DATE_COLUMN = "date"
TARGET_COLUMN = "revenue"
```

Your CSV needs a date column and a numeric target column. The rest is automatic.

## Output

After running, check `outputs/`:
- `forecast.png` — actuals + holdout + 30-day forecast
- `feature_importance.png` — which features the model uses most
- `report.md` — written summary with error metrics and what they mean
