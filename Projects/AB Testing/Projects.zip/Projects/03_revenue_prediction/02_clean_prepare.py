"""
02_clean_prepare.py — Feature engineering for time-series forecasting.

We add three families of features:
  - Calendar:    day-of-week, month, day-of-year, is_weekend
  - Lag:         revenue shifted back 1, 7, 14, 28 days
  - Rolling:     7- and 28-day moving averages and standard deviations

Lags and rolling windows are the workhorses of time-series ML.
They give the model recent context without leaking future information.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    df["dayofweek"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month
    df["dayofyear"] = df["date"].dt.dayofyear
    df["is_weekend"] = df["dayofweek"].isin([5, 6]).astype(int)
    return df


def add_lag_features(df: pd.DataFrame) -> pd.DataFrame:
    for lag in config.LAG_DAYS:
        df[f"lag_{lag}"] = df["revenue"].shift(lag)
    return df


def add_rolling_features(df: pd.DataFrame) -> pd.DataFrame:
    # IMPORTANT: shift(1) so the rolling window doesn't include today
    # (otherwise the model would peek at the answer)
    for w in config.ROLLING_WINDOWS:
        df[f"roll_mean_{w}"] = df["revenue"].shift(1).rolling(w).mean()
        df[f"roll_std_{w}"]  = df["revenue"].shift(1).rolling(w).std()
    return df


def main():
    df = pd.read_csv(config.RAW_DATA_PATH, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)
    print(f"Loaded {len(df):,} rows")

    df = add_calendar_features(df)
    df = add_lag_features(df)
    df = add_rolling_features(df)

    before = len(df)
    df = df.dropna().reset_index(drop=True)
    print(f"Dropped {before - len(df)} rows that had missing lag/rolling values")
    print(f"Features: {list(df.columns)}")

    df.to_csv(config.FEATURES_PATH, index=False)
    print(f"Saved → {config.FEATURES_PATH}")


if __name__ == "__main__":
    main()
