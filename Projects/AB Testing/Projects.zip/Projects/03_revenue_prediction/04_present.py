"""
04_present.py — Visualize the forecast and write the report.
"""

import sys
import json
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def make_forecast_chart(out_path: Path):
    history = pd.read_csv("data/raw_data.csv", parse_dates=["date"])
    test_pred = pd.read_csv("data/test_predictions.csv", parse_dates=["date"])
    forecast = pd.read_csv("data/forecast.csv", parse_dates=["date"])

    fig, ax = plt.subplots(figsize=(14, 6))

    # Training history
    train_end = test_pred["date"].min()
    train = history[history["date"] < train_end]
    ax.plot(train["date"], train["revenue"],
            color="#0B2545", lw=1, alpha=0.7, label="Training data")

    # Actual vs predicted in test window
    ax.plot(test_pred["date"], test_pred["revenue"],
            color="#0B2545", lw=1.5, label="Test actual")
    ax.plot(test_pred["date"], test_pred["predicted"],
            color="#B85042", lw=1.5, ls="--", label="Test predicted")

    # Future forecast
    ax.plot(forecast["date"], forecast["revenue"],
            color="#0E7C7B", lw=2, label=f"{len(forecast)}-day forecast")
    ax.axvspan(forecast["date"].min(), forecast["date"].max(),
               alpha=0.1, color="#0E7C7B")

    ax.set_title("Revenue forecast — history, test, future")
    ax.set_xlabel("Date")
    ax.set_ylabel("Revenue")
    ax.legend(loc="upper left")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_importance_chart(out_path: Path):
    imp = pd.read_csv("data/feature_importance.csv").head(12)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(imp["feature"][::-1], imp["importance"][::-1], color="#0E7C7B")
    ax.set_title("Top 12 most important features")
    ax.set_xlabel("Importance")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def write_report(results: dict, out_path: Path):
    m = results["metrics"]["model"]
    n = results["metrics"]["naive"]

    report = f"""# Revenue / Volume Forecast Report

## Model performance on holdout

| Metric | LightGBM Model | Naive Baseline | Improvement |
|--------|----------------|----------------|-------------|
| MAE  | {m['MAE']:.1f} | {n['MAE']:.1f} | {(n['MAE']-m['MAE'])/n['MAE']*100:+.1f}% |
| RMSE | {m['RMSE']:.1f} | {n['RMSE']:.1f} | {(n['RMSE']-m['RMSE'])/n['RMSE']*100:+.1f}% |
| MAPE | {m['MAPE']:.2f}% | {n['MAPE']:.2f}% | {(n['MAPE']-m['MAPE'])/n['MAPE']*100:+.1f}% |

- **MAE** (mean absolute error) — on average, predictions are off by this many units in either direction.
- **RMSE** — like MAE but penalizes big errors more heavily.
- **MAPE** — average error as a percentage of the actual value. Easier for executives to read.

The naive baseline simply predicts that tomorrow's value equals today's. If the model can't beat this, it's not worth using.

---

## Forecast for the next {results['forecast_horizon_days']} days

- **Predicted total:** {results['forecast_total']:,.0f}
- **Predicted daily average:** {results['forecast_daily_avg']:,.1f}

See `forecast.png` for the visual.

---

## What the model learned

See `feature_importance.png` for the top features. The most important ones tell you what actually drives the outcome — useful information beyond the prediction itself.

---

## How to use this

1. Use the forecast for **capacity / budget planning** — but treat it as one input, not as truth.
2. Watch the MAPE — anything under 10% is good for most business contexts.
3. Re-train the model **every week or month** as new actual data comes in.
4. If the model's accuracy on recent data drops, that's a sign the underlying pattern has changed (called *drift*).

---

## Caveats

- A model trained on past data assumes the future *resembles* the past. If a major change happens (new product, new market, pandemic), the forecast will be wrong.
- Recursive multi-step forecasting (predicting today, using that to predict tomorrow, etc.) can accumulate errors. Short horizons are more reliable than long ones.
"""
    out_path.write_text(report, encoding="utf-8")
    print(f"Saved → {out_path}")


def main():
    out_dir = Path(config.OUTPUT_DIR)
    out_dir.mkdir(exist_ok=True)

    with open(out_dir / "results.json") as f:
        results = json.load(f)

    make_forecast_chart(out_dir / "forecast.png")
    make_importance_chart(out_dir / "feature_importance.png")
    write_report(results, out_dir / "report.md")
    print("\nDone. Open the outputs/ folder.")


if __name__ == "__main__":
    main()
