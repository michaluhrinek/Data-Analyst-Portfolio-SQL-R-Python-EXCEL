"""
03_analyze.py — Train a LightGBM model and forecast.

We do a time-based train/test split (NOT random — that would leak future
information into the training set). We evaluate on the holdout, then
re-train on all data and forecast FORECAST_HORIZON_DAYS into the future
using a recursive multi-step strategy.
"""

import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, mean_squared_error

sys.path.insert(0, str(Path(__file__).parent))
import config

TARGET = "revenue"
DROP_FROM_FEATURES = {"date", TARGET}


def split_by_time(df: pd.DataFrame, test_size: float):
    split_idx = int(len(df) * (1 - test_size))
    return df.iloc[:split_idx].copy(), df.iloc[split_idx:].copy()


def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    return mae, rmse, mape


def recursive_forecast(model, history: pd.DataFrame, n_days: int,
                       feature_cols: list[str]) -> pd.DataFrame:
    """Forecast n_days ahead, using each prediction as input for the next."""
    history = history.copy()
    forecasts = []

    for _ in range(n_days):
        last_date = history["date"].iloc[-1]
        next_date = last_date + pd.Timedelta(days=1)

        # Build features for next_date from history
        row = {
            "date": next_date,
            "dayofweek": next_date.dayofweek,
            "month": next_date.month,
            "dayofyear": next_date.dayofyear,
            "is_weekend": int(next_date.dayofweek in (5, 6)),
        }
        for lag in config.LAG_DAYS:
            row[f"lag_{lag}"] = history["revenue"].iloc[-lag]
        for w in config.ROLLING_WINDOWS:
            recent = history["revenue"].iloc[-w:]
            row[f"roll_mean_{w}"] = recent.mean()
            row[f"roll_std_{w}"]  = recent.std()

        X = pd.DataFrame([{c: row[c] for c in feature_cols}])
        yhat = float(model.predict(X)[0])

        row["revenue"] = yhat
        forecasts.append(row)
        history = pd.concat([history, pd.DataFrame([row])], ignore_index=True)

    return pd.DataFrame(forecasts)


def main():
    df = pd.read_csv(config.FEATURES_PATH, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)

    feature_cols = [c for c in df.columns if c not in DROP_FROM_FEATURES]

    # ── Time-based train/test split ──────────────────────────────────────
    train, test = split_by_time(df, config.TEST_SIZE)
    print(f"Train: {len(train):,} rows ({train['date'].min().date()} → "
          f"{train['date'].max().date()})")
    print(f"Test:  {len(test):,} rows ({test['date'].min().date()} → "
          f"{test['date'].max().date()})")

    X_train, y_train = train[feature_cols], train[TARGET]
    X_test, y_test = test[feature_cols], test[TARGET]

    # ── Train model ──────────────────────────────────────────────────────
    model = lgb.LGBMRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        num_leaves=31,
        random_state=config.RANDOM_SEED,
        verbose=-1,
    )
    model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              callbacks=[lgb.early_stopping(30, verbose=False)])

    # ── Evaluate on holdout ──────────────────────────────────────────────
    test_pred = model.predict(X_test)
    mae, rmse, mape = evaluate(y_test.to_numpy(), test_pred)

    # Naive baseline: predict tomorrow = today
    naive_pred = test["lag_1"].to_numpy()
    n_mae, n_rmse, n_mape = evaluate(y_test.to_numpy(), naive_pred)

    print(f"\nHoldout performance:")
    print(f"  Model — MAE: {mae:.1f}   RMSE: {rmse:.1f}   MAPE: {mape:.2f}%")
    print(f"  Naive — MAE: {n_mae:.1f}   RMSE: {n_rmse:.1f}   MAPE: {n_mape:.2f}%")
    improvement_pct = (n_mae - mae) / n_mae * 100
    print(f"  Model beats naive by {improvement_pct:.1f}% (lower MAE is better)")

    # ── Save test predictions ────────────────────────────────────────────
    test_out = test[["date", TARGET]].copy()
    test_out["predicted"] = test_pred
    Path("data").mkdir(exist_ok=True)
    test_out.to_csv("data/test_predictions.csv", index=False)

    # ── Refit on all data and forecast forward ───────────────────────────
    model_full = lgb.LGBMRegressor(
        n_estimators=model.best_iteration_ or 500,
        learning_rate=0.05, max_depth=6, num_leaves=31,
        random_state=config.RANDOM_SEED, verbose=-1,
    )
    model_full.fit(df[feature_cols], df[TARGET])

    history = df[["date", TARGET]].copy()
    forecast_df = recursive_forecast(model_full, history,
                                     config.FORECAST_HORIZON_DAYS,
                                     feature_cols)
    forecast_df.to_csv(Path("data/forecast.csv"), index=False)

    # ── Save feature importances ─────────────────────────────────────────
    importances = pd.DataFrame({
        "feature": feature_cols,
        "importance": model_full.feature_importances_,
    }).sort_values("importance", ascending=False)
    importances.to_csv("data/feature_importance.csv", index=False)

    # ── Save metrics ─────────────────────────────────────────────────────
    results = {
        "train_size": len(train),
        "test_size": len(test),
        "metrics": {
            "model": {"MAE": float(mae), "RMSE": float(rmse), "MAPE": float(mape)},
            "naive": {"MAE": float(n_mae), "RMSE": float(n_rmse), "MAPE": float(n_mape)},
            "improvement_over_naive_pct": float(improvement_pct),
        },
        "forecast_horizon_days": config.FORECAST_HORIZON_DAYS,
        "forecast_total": float(forecast_df["revenue"].sum()),
        "forecast_daily_avg": float(forecast_df["revenue"].mean()),
    }
    Path(config.OUTPUT_DIR).mkdir(exist_ok=True)
    with open(Path(config.OUTPUT_DIR) / "results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved → {config.OUTPUT_DIR}/results.json")


if __name__ == "__main__":
    main()
