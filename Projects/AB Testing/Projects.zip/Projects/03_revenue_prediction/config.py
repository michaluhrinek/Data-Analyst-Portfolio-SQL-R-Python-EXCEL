"""
Configuration for Project 3 — Revenue / Volume Prediction
"""

# ─── DATA SOURCE ─────────────────────────────────────────────────────────────
USE_SYNTHETIC = True
INPUT_FILE = None  # e.g. "data/my_sales.csv"

# ─── DATA SCHEMA (only used when INPUT_FILE is set) ──────────────────────────
DATE_COLUMN = "date"
TARGET_COLUMN = "revenue"

# ─── SYNTHETIC DATA PARAMETERS ───────────────────────────────────────────────
START_DATE = "2022-01-01"
END_DATE = "2024-12-31"
BASELINE = 1000
GROWTH_PER_DAY = 0.4   # gradual upward trend
WEEKLY_AMPLITUDE = 200 # weekly seasonality strength
NOISE_STD = 80
RANDOM_SEED = 42

# ─── MODEL PARAMETERS ────────────────────────────────────────────────────────
TEST_SIZE = 0.20            # last 20% of time used as the holdout
FORECAST_HORIZON_DAYS = 30  # forecast this many days into the future
LAG_DAYS = [1, 7, 14, 28]
ROLLING_WINDOWS = [7, 28]

# ─── FILE PATHS ──────────────────────────────────────────────────────────────
RAW_DATA_PATH = "data/raw_data.csv"
FEATURES_PATH = "data/features.csv"
OUTPUT_DIR = "outputs"
