"""
04_present.py — Generate the chart and the written report.

Outputs:
  - outputs/distribution_comparison.png
  - outputs/report.md
"""

import sys
import json
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def make_chart(df: pd.DataFrame, out_path: Path):
    """Two-panel chart: time series + histogram overlay."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Panel 1: time series colored by group
    for grp, color in [("A", "#0B2545"), ("B", "#0E7C7B")]:
        sub = df[df["group"] == grp]
        ax1.plot(sub["date"], sub["value"], color=color, lw=0.9,
                 label=f"Group {grp}")
    ax1.axvline(pd.Timestamp(config.SPLIT_DATE), color="#B85042",
                ls="--", lw=1.2, label=f"Split: {config.SPLIT_DATE}")
    ax1.set_title("Time series — split into two groups")
    ax1.set_xlabel("Date")
    ax1.set_ylabel("Value")
    ax1.legend(loc="best")
    ax1.grid(alpha=0.3)

    # Panel 2: histogram overlay
    a = df.loc[df["group"] == "A", "value"]
    b = df.loc[df["group"] == "B", "value"]
    ax2.hist(a, bins=40, color="#0B2545", alpha=0.55, label="Group A", density=True)
    ax2.hist(b, bins=40, color="#0E7C7B", alpha=0.55, label="Group B", density=True)
    ax2.axvline(a.mean(), color="#0B2545", ls="--", lw=1)
    ax2.axvline(b.mean(), color="#0E7C7B", ls="--", lw=1)
    ax2.set_title("Distribution comparison")
    ax2.set_xlabel("Value")
    ax2.set_ylabel("Density")
    ax2.legend()
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def write_report(results: dict, out_path: Path):
    a = results["group_A"]
    b = results["group_B"]
    t = results["ttest"]
    lv = results["levene"]

    mean_verdict = (
        f"**The means ARE statistically different** (p = {t['p_value']:.4g}). "
        f"Group A averaged {a['mean']:.4f} vs Group B at {b['mean']:.4f}. "
        f"Cohen's d = {t['cohens_d']:.3f} ({t['effect_size']} effect size)."
        if t["significant"]
        else
        f"**No significant difference in means** (p = {t['p_value']:.4g} > "
        f"{results['alpha']}). The observed difference between "
        f"{a['mean']:.4f} and {b['mean']:.4f} could plausibly be due to chance."
    )

    var_verdict = (
        f"**Variance IS statistically different** (p = {lv['p_value']:.4g}). "
        f"Group A std = {a['std']:.4f}, Group B std = {b['std']:.4f}. "
        f"The series became {'more' if b['std'] > a['std'] else 'less'} volatile."
        if lv["significant"]
        else
        f"**No significant difference in variance** "
        f"(p = {lv['p_value']:.4g} > {results['alpha']})."
    )

    report = f"""# Hypothesis Test Report

**Question:** Did the value change between the two periods?

**Split date:** {results['split_date']}
**Significance level (alpha):** {results['alpha']}

---

## Summary statistics

| Group | n | Mean | Std | Min | Max |
|-------|---|------|-----|-----|-----|
| A (before) | {a['n']:,} | {a['mean']:.4f} | {a['std']:.4f} | {a['min']:.4f} | {a['max']:.4f} |
| B (after)  | {b['n']:,} | {b['mean']:.4f} | {b['std']:.4f} | {b['min']:.4f} | {b['max']:.4f} |

---

## Test 1 — Welch's t-test (difference in means)

- **t-statistic:** {t['statistic']:.4f}
- **p-value:** {t['p_value']:.6f}
- **Cohen's d (effect size):** {t['cohens_d']:.3f} → *{t['effect_size']}*

**Conclusion:** {mean_verdict}

---

## Test 2 — Levene's test (difference in variance)

- **statistic:** {lv['statistic']:.4f}
- **p-value:** {lv['p_value']:.6f}

**Conclusion:** {var_verdict}

---

## How to read this

- A **p-value below {results['alpha']}** means the observed difference is unlikely to be due to chance — the effect is "statistically significant."
- **Statistical significance ≠ practical importance.** That's what effect size (Cohen's d) is for: even a tiny difference can be significant with enough data.
- Cohen's d guide: 0.2 = small, 0.5 = medium, 0.8 = large.

See `distribution_comparison.png` for the visual.
"""
    out_path.write_text(report, encoding="utf-8")
    print(f"Saved → {out_path}")


def main():
    out_dir = Path(config.OUTPUT_DIR)
    out_dir.mkdir(exist_ok=True)

    df = pd.read_csv(config.CLEAN_DATA_PATH, parse_dates=["date"])
    with open(out_dir / "results.json") as f:
        results = json.load(f)

    make_chart(df, out_dir / "distribution_comparison.png")
    write_report(results, out_dir / "report.md")
    print("\nDone. Open the outputs/ folder to see the results.")


if __name__ == "__main__":
    main()
