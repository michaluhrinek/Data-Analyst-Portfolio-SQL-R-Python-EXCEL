"""
02_clean_prepare.py — Clean the data and split it into two groups for testing.

Steps:
  1. Load raw data
  2. Validate date range and remove obvious outliers (>5 sigma)
  3. Add a 'group' column based on SPLIT_DATE ('A' or 'B')
  4. Save cleaned data
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def main():
    df = pd.read_csv(config.RAW_DATA_PATH, parse_dates=["date"])
    print(f"Loaded raw data: {len(df):,} rows")

    # Remove >5σ outliers (common-sense data hygiene)
    mean, std = df["value"].mean(), df["value"].std()
    before = len(df)
    df = df[(df["value"] - mean).abs() <= 5 * std].reset_index(drop=True)
    print(f"Removed {before - len(df)} outliers beyond 5 sigma")

    # Split into two groups
    split = pd.Timestamp(config.SPLIT_DATE)
    df["group"] = np.where(df["date"] < split, "A", "B")

    counts = df["group"].value_counts().to_dict()
    print(f"Group A (before {config.SPLIT_DATE}): {counts.get('A', 0):,} rows")
    print(f"Group B (after  {config.SPLIT_DATE}): {counts.get('B', 0):,} rows")

    if counts.get("A", 0) < 30 or counts.get("B", 0) < 30:
        print("WARNING: one group has fewer than 30 observations — "
              "statistical tests will have low power.")

    df.to_csv(config.CLEAN_DATA_PATH, index=False)
    print(f"Saved → {config.CLEAN_DATA_PATH}")


if __name__ == "__main__":
    main()
