"""
03_analyze.py — The statistical core: hypothesis testing.

Two tests are run:
  1. Welch's t-test         → are the MEAN values different?
  2. Levene's test for variance → is the VOLATILITY different?

We also compute effect size (Cohen's d) because p-values alone
don't tell you whether a difference is meaningfully large.

Outputs a dict that 04_present.py turns into a report.
"""

import sys
import json
import pandas as pd
import numpy as np
from scipy import stats
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Standardized difference between two means."""
    n1, n2 = len(a), len(b)
    s1, s2 = a.std(ddof=1), b.std(ddof=1)
    pooled = np.sqrt(((n1 - 1) * s1**2 + (n2 - 1) * s2**2) / (n1 + n2 - 2))
    return (a.mean() - b.mean()) / pooled if pooled else 0.0


def interpret_d(d: float) -> str:
    d = abs(d)
    if d < 0.2:  return "negligible"
    if d < 0.5:  return "small"
    if d < 0.8:  return "medium"
    return "large"


def main():
    df = pd.read_csv(config.CLEAN_DATA_PATH, parse_dates=["date"])

    a = df.loc[df["group"] == "A", "value"].to_numpy()
    b = df.loc[df["group"] == "B", "value"].to_numpy()

    # ── Descriptive stats ────────────────────────────────────────────────
    summary = {
        "split_date": config.SPLIT_DATE,
        "alpha": config.ALPHA,
        "group_A": {
            "n": int(len(a)),
            "mean": float(a.mean()),
            "std": float(a.std(ddof=1)),
            "min": float(a.min()),
            "max": float(a.max()),
        },
        "group_B": {
            "n": int(len(b)),
            "mean": float(b.mean()),
            "std": float(b.std(ddof=1)),
            "min": float(b.min()),
            "max": float(b.max()),
        },
    }

    # ── Test 1: are the MEANS different? (Welch's t-test) ───────────────
    t_stat, t_p = stats.ttest_ind(a, b, equal_var=False)
    d = cohens_d(a, b)
    summary["ttest"] = {
        "statistic": float(t_stat),
        "p_value": float(t_p),
        "significant": bool(t_p < config.ALPHA),
        "cohens_d": float(d),
        "effect_size": interpret_d(d),
    }

    # ── Test 2: are the VARIANCES different? (Levene's test) ────────────
    lev_stat, lev_p = stats.levene(a, b, center="median")
    summary["levene"] = {
        "statistic": float(lev_stat),
        "p_value": float(lev_p),
        "significant": bool(lev_p < config.ALPHA),
    }

    # ── Pretty print to console ─────────────────────────────────────────
    print("\n" + "=" * 60)
    print("HYPOTHESIS TESTING RESULTS")
    print("=" * 60)
    print(f"\nGroup A (before {config.SPLIT_DATE}):")
    print(f"  n = {summary['group_A']['n']:,}, "
          f"mean = {summary['group_A']['mean']:.4f}, "
          f"std = {summary['group_A']['std']:.4f}")
    print(f"Group B (after  {config.SPLIT_DATE}):")
    print(f"  n = {summary['group_B']['n']:,}, "
          f"mean = {summary['group_B']['mean']:.4f}, "
          f"std = {summary['group_B']['std']:.4f}")

    print(f"\n[1] Welch's t-test — are the means different?")
    print(f"    t = {t_stat:.4f},  p = {t_p:.6f}")
    print(f"    Cohen's d = {d:.3f} ({interpret_d(d)} effect)")
    print(f"    Significant at alpha={config.ALPHA}? "
          f"{'YES' if t_p < config.ALPHA else 'NO'}")

    print(f"\n[2] Levene's test — are the variances different?")
    print(f"    statistic = {lev_stat:.4f},  p = {lev_p:.6f}")
    print(f"    Significant at alpha={config.ALPHA}? "
          f"{'YES' if lev_p < config.ALPHA else 'NO'}")
    print()

    # Save for the presentation step
    Path(config.OUTPUT_DIR).mkdir(exist_ok=True)
    with open(Path(config.OUTPUT_DIR) / "results.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Saved → {config.OUTPUT_DIR}/results.json")


if __name__ == "__main__":
    main()
