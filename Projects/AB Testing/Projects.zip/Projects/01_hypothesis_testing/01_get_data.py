"""
01_get_data.py — Fetch or generate the dataset.

Sources:
  - ECB Data Portal (Statistical Data Warehouse): daily EUR/USD exchange rates
  - Synthetic fallback: simulated exchange rate series with two regimes

Outputs:
  - data/raw_data.csv  (date, value)
"""

import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path

# Make config importable when running from inside the project folder
sys.path.insert(0, str(Path(__file__).parent))
import config


def fetch_ecb_eurusd() -> pd.DataFrame:
    """Download daily EUR/USD reference rate from the ECB.

    The ECB Data Portal exposes a CSV endpoint for the FX dataset.
    Series key: EXR.D.USD.EUR.SP00.A  (Daily / USD / EUR / Spot / Average)
    """
    url = (
        "https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A"
        "?format=csvdata"
    )
    print(f"Fetching ECB EUR/USD rates from {url} ...")
    df = pd.read_csv(url)

    # The ECB CSV uses TIME_PERIOD and OBS_VALUE
    df = df[["TIME_PERIOD", "OBS_VALUE"]].rename(
        columns={"TIME_PERIOD": "date", "OBS_VALUE": "value"}
    )
    df["date"] = pd.to_datetime(df["date"])
    df = df.dropna().sort_values("date").reset_index(drop=True)
    print(f"  → got {len(df):,} daily observations "
          f"from {df['date'].min().date()} to {df['date'].max().date()}")
    return df


def generate_synthetic_data() -> pd.DataFrame:
    """Generate a synthetic exchange-rate-like series with a regime shift."""
    rng = np.random.default_rng(seed=42)

    dates = pd.date_range("2022-01-01", "2025-06-30", freq="B")  # business days
    n = len(dates)

    # Two regimes: lower mean & lower vol before SPLIT_DATE,
    # higher mean & higher vol after.
    split_idx = sum(d < pd.Timestamp(config.SPLIT_DATE) for d in dates)

    # Random walk starting at 1.10, with regime-dependent volatility
    returns = np.concatenate([
        rng.normal(loc=0.0,    scale=0.003, size=split_idx),
        rng.normal(loc=0.0002, scale=0.006, size=n - split_idx),
    ])
    values = 1.10 * np.exp(np.cumsum(returns))

    df = pd.DataFrame({"date": dates, "value": values})
    print(f"  → generated {len(df):,} synthetic observations")
    return df


def load_user_file(path: str) -> pd.DataFrame:
    """Load a user-supplied CSV and normalize column names."""
    print(f"Loading user data from {path} ...")
    df = pd.read_csv(path)
    df = df[[config.DATE_COLUMN, config.VALUE_COLUMN]].rename(
        columns={config.DATE_COLUMN: "date", config.VALUE_COLUMN: "value"}
    )
    df["date"] = pd.to_datetime(df["date"])
    df = df.dropna().sort_values("date").reset_index(drop=True)
    print(f"  → loaded {len(df):,} observations")
    return df


def main():
    Path("data").mkdir(exist_ok=True)

    if config.INPUT_FILE:
        df = load_user_file(config.INPUT_FILE)
    elif config.USE_REAL_DATA:
        try:
            df = fetch_ecb_eurusd()
        except Exception as exc:
            print(f"ECB fetch failed ({exc}). Falling back to synthetic data.")
            df = generate_synthetic_data()
    else:
        df = generate_synthetic_data()

    df.to_csv(config.RAW_DATA_PATH, index=False)
    print(f"Saved → {config.RAW_DATA_PATH}")


if __name__ == "__main__":
    main()
