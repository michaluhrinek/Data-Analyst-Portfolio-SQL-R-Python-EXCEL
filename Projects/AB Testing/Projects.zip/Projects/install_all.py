"""
install_all.py — install all dependencies for all five projects in one go.

Usage (from the Projects/ folder):
    python install_all.py
"""

import subprocess
import sys
from pathlib import Path

PROJECTS = [
    "01_hypothesis_testing",
    "02_ab_testing",
    "03_revenue_prediction",
    "04_churn_prediction",
    "05_marketing_analysis",
]

HERE = Path(__file__).parent


def main():
    print("Installing dependencies for all five projects...\n")
    for proj in PROJECTS:
        req = HERE / proj / "requirements.txt"
        if req.exists():
            print(f"→ {proj}")
            subprocess.check_call([
                sys.executable, "-m", "pip", "install", "-q", "-r", str(req)
            ])
    print("\nAll dependencies installed.")
    print("\nTo run a project:")
    print("    cd 01_hypothesis_testing")
    print("    python run_all.py")


if __name__ == "__main__":
    main()
