# Project 4 — Churn Prediction

**Question:** Which customers are about to leave?

## What you'll learn

- Framing a binary classification problem
- Handling class imbalance (most customers don't churn)
- Logistic regression and gradient boosting for classification
- Why **accuracy is the wrong metric** for imbalanced problems
- AUC-ROC, precision, recall, and Precision@K (the most business-relevant)
- Reading a confusion matrix

## What this project does

1. Generates 5,000 synthetic customers with realistic behavioral features (or loads your CSV)
2. Engineers churn-relevant features
3. Trains a LightGBM classifier with class weighting
4. Compares performance against a logistic regression baseline
5. Identifies the top at-risk customers (Precision@K)
6. Produces ROC curve, precision-recall curve, and a written report

## How to run

```bash
pip install -r requirements.txt
python run_all.py
```

## Using your own data

Edit `config.py`:

```python
USE_SYNTHETIC = False
INPUT_FILE = "data/my_customers.csv"
TARGET_COLUMN = "churned"  # column with 0/1
```

## Output

After running, check `outputs/`:
- `roc_curve.png` — model performance overall
- `confusion_matrix.png` — how predictions break down
- `top_at_risk.csv` — the highest-risk customers to act on first
- `report.md` — written summary with business interpretation
