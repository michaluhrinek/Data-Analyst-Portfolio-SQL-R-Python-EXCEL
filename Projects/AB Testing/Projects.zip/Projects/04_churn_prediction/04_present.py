"""04_present.py — Charts + report for churn project."""

import sys
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def make_roc_chart(out_path: Path):
    roc = pd.read_csv("data/roc.csv")
    pr  = pd.read_csv("data/pr.csv")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    ax1.plot(roc["fpr"], roc["tpr"], color="#0E7C7B", lw=2.5)
    ax1.plot([0, 1], [0, 1], color="#999", ls="--", lw=1, label="Random guess")
    ax1.set_xlabel("False positive rate")
    ax1.set_ylabel("True positive rate")
    ax1.set_title("ROC curve")
    ax1.grid(alpha=0.3)
    ax1.legend()

    ax2.plot(pr["recall"], pr["precision"], color="#0B2545", lw=2.5)
    ax2.set_xlabel("Recall")
    ax2.set_ylabel("Precision")
    ax2.set_title("Precision–Recall curve")
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_confusion_chart(results: dict, out_path: Path):
    cm = results["confusion_matrix"]
    matrix = np.array([[cm["true_negative"], cm["false_positive"]],
                       [cm["false_negative"], cm["true_positive"]]])

    fig, ax = plt.subplots(figsize=(7, 5.5))
    im = ax.imshow(matrix, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{matrix[i, j]}", ha="center", va="center",
                    fontsize=18, fontweight="bold",
                    color="white" if matrix[i, j] > matrix.max() / 2 else "black")
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(["Predicted: stay", "Predicted: churn"])
    ax.set_yticklabels(["Actual: stay", "Actual: churn"])
    ax.set_title(f"Confusion matrix ({results['best_model']})")
    plt.colorbar(im, ax=ax, fraction=0.046)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def make_importance_chart(out_path: Path):
    imp = pd.read_csv("data/feature_importance.csv").head(10)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(imp["feature"][::-1], imp["importance"][::-1], color="#0E7C7B")
    ax.set_title("Top 10 features driving churn predictions")
    ax.set_xlabel("Importance")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"Saved → {out_path}")


def write_report(results: dict, out_path: Path):
    best = results["best_model"]
    m = results["metrics"]["lightgbm" if best == "LightGBM" else "logistic_regression"]
    cm = results["confusion_matrix"]
    k = results["top_k"]

    report = f"""# Churn Prediction Report

## Overview

- Trained two models on **{results['n_train']:,}** customers
- Evaluated on **{results['n_test']:,}** held-out customers
- Baseline churn rate in test set: **{results['test_churn_rate']:.1%}**
- Best model on this run: **{best}**

---

## Model performance (best model)

| Metric | Value | What it means |
|--------|-------|---------------|
| AUC-ROC | {m['AUC']:.4f} | How well the model ranks churners above non-churners. 0.5 = random, 1.0 = perfect. |
| Precision | {m['Precision']:.4f} | Of customers we predict will churn, what fraction actually do. |
| Recall | {m['Recall']:.4f} | Of customers who actually churn, what fraction we catch. |
| F1 | {m['F1']:.4f} | Balance of precision and recall. |
| Precision@{k} | {m[f'Precision@{k}']:.4f} | **Most business-relevant.** Of the top {k} customers we flag, what % actually churn. |

---

## Confusion matrix

|  | Predicted: stay | Predicted: churn |
|---|---|---|
| **Actual: stay**  | {cm['true_negative']} (true negative) | {cm['false_positive']} (false positive) |
| **Actual: churn** | {cm['false_negative']} (false negative) | {cm['true_positive']} (true positive) |

- **False positives** are customers we'd waste retention effort on.
- **False negatives** are churners we'd miss entirely — usually the more painful error.

---

## How to use this in production

1. Score all customers weekly. Sort by `churn_probability` descending.
2. Take the top {k} — that's your action list.
3. Send each one a targeted retention intervention (discount, outreach, feature unlock).
4. **Run that intervention as an A/B test** (see Project 2). Half get the intervention, half don't. Did it actually reduce churn? Without an A/B test, you'll never know if the model's outputs translate to retained revenue.
5. Re-train monthly. As behaviors shift, the model drifts.

---

## Common pitfalls

- **Don't use accuracy.** With an 18% churn rate, predicting "everyone stays" gives 82% accuracy and zero business value.
- **Class imbalance matters.** Most customers don't churn. We use `class_weight="balanced"` so the model takes the minority class seriously.
- **Calibration ≠ ranking.** A 0.8 probability doesn't literally mean an 80% churn chance unless the model is calibrated. The relative ranking is what matters for prioritization.

See `roc_curve.png`, `confusion_matrix.png`, `feature_importance.png`, and `top_at_risk.csv` for details.
"""
    out_path.write_text(report, encoding="utf-8")
    print(f"Saved → {out_path}")


def main():
    out_dir = Path(config.OUTPUT_DIR)
    out_dir.mkdir(exist_ok=True)
    with open(out_dir / "results.json") as f:
        results = json.load(f)

    make_roc_chart(out_dir / "roc_curve.png")
    make_confusion_chart(results, out_dir / "confusion_matrix.png")
    make_importance_chart(out_dir / "feature_importance.png")
    write_report(results, out_dir / "report.md")
    print("\nDone. Open the outputs/ folder.")


if __name__ == "__main__":
    main()
