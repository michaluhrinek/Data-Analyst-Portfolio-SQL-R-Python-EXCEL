"""
03_analyze.py — Train churn models and evaluate.

We train two models for comparison:
  1. Logistic Regression — interpretable baseline
  2. LightGBM            — usually the strongest performer on tabular data

We evaluate using AUC-ROC, precision, recall, and Precision@K
(the most business-meaningful: of the top K customers we flag,
how many actually churn?).
"""

import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_curve, precision_recall_curve
)
import lightgbm as lgb

sys.path.insert(0, str(Path(__file__).parent))
import config

TARGET = "churned"
ID_COLS = {"customer_id"}


def precision_at_k(y_true, y_score, k):
    order = np.argsort(y_score)[::-1][:k]
    return float(np.mean(np.array(y_true)[order]))


def main():
    df = pd.read_csv(config.CLEAN_DATA_PATH)

    feature_cols = [c for c in df.columns
                    if c not in ID_COLS and c != TARGET]
    X, y = df[feature_cols], df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=config.TEST_SIZE,
        stratify=y, random_state=config.RANDOM_SEED
    )
    print(f"Train: {len(X_train):,} (churn rate {y_train.mean():.1%})")
    print(f"Test:  {len(X_test):,} (churn rate {y_test.mean():.1%})")

    # ── Model 1: Logistic Regression (baseline) ──────────────────────────
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    logit = LogisticRegression(class_weight="balanced",
                               max_iter=1000,
                               random_state=config.RANDOM_SEED)
    logit.fit(X_train_s, y_train)
    proba_logit = logit.predict_proba(X_test_s)[:, 1]
    pred_logit = (proba_logit > 0.5).astype(int)

    # ── Model 2: LightGBM ────────────────────────────────────────────────
    gbm = lgb.LGBMClassifier(
        n_estimators=400, learning_rate=0.05, max_depth=6, num_leaves=31,
        class_weight="balanced", random_state=config.RANDOM_SEED, verbose=-1,
    )
    gbm.fit(X_train, y_train,
            eval_set=[(X_test, y_test)],
            callbacks=[lgb.early_stopping(30, verbose=False)])
    proba_gbm = gbm.predict_proba(X_test)[:, 1]
    pred_gbm = (proba_gbm > 0.5).astype(int)

    # ── Evaluate ─────────────────────────────────────────────────────────
    def metrics(name, y, proba, pred):
        auc = roc_auc_score(y, proba)
        prec = precision_score(y, pred, zero_division=0)
        rec = recall_score(y, pred)
        f1 = f1_score(y, pred)
        p_at_k = precision_at_k(y.to_numpy(), proba,
                                min(config.TOP_K_AT_RISK, len(y)))
        print(f"\n{name}:")
        print(f"  AUC-ROC:        {auc:.4f}")
        print(f"  Precision:      {prec:.4f}")
        print(f"  Recall:         {rec:.4f}")
        print(f"  F1:             {f1:.4f}")
        print(f"  Precision@{config.TOP_K_AT_RISK}:   {p_at_k:.4f}")
        return {"AUC": float(auc), "Precision": float(prec),
                "Recall": float(rec), "F1": float(f1),
                f"Precision@{config.TOP_K_AT_RISK}": float(p_at_k)}

    print("\n" + "=" * 60)
    print("MODEL PERFORMANCE")
    print("=" * 60)
    m_logit = metrics("Logistic Regression", y_test, proba_logit, pred_logit)
    m_gbm = metrics("LightGBM",            y_test, proba_gbm,   pred_gbm)

    # Pick the better model for the rest
    best_proba = proba_gbm if m_gbm["AUC"] >= m_logit["AUC"] else proba_logit
    best_pred = pred_gbm if m_gbm["AUC"] >= m_logit["AUC"] else pred_logit
    best_name = "LightGBM" if m_gbm["AUC"] >= m_logit["AUC"] else "Logistic Regression"
    print(f"\n→ Best model on this run: {best_name}")

    # ── Confusion matrix data ────────────────────────────────────────────
    cm = confusion_matrix(y_test, best_pred)
    tn, fp, fn, tp = cm.ravel()
    print(f"\nConfusion matrix (best model):")
    print(f"  True positives:  {tp}   (correctly flagged churners)")
    print(f"  False positives: {fp}   (flagged but didn't churn)")
    print(f"  False negatives: {fn}   (churned but missed)")
    print(f"  True negatives:  {tn}   (correctly identified as safe)")

    # ── ROC + PR curves for plotting ─────────────────────────────────────
    fpr, tpr, _ = roc_curve(y_test, best_proba)
    prec_vals, rec_vals, _ = precision_recall_curve(y_test, best_proba)
    Path("data").mkdir(exist_ok=True)
    pd.DataFrame({"fpr": fpr, "tpr": tpr}).to_csv("data/roc.csv", index=False)
    pd.DataFrame({"precision": prec_vals, "recall": rec_vals}).to_csv(
        "data/pr.csv", index=False)

    # ── Top at-risk customers ────────────────────────────────────────────
    test_df = X_test.copy()
    test_df["customer_id"] = df.loc[X_test.index, "customer_id"].values \
        if "customer_id" in df.columns else X_test.index
    test_df["actual_churned"] = y_test.values
    test_df["churn_probability"] = best_proba
    top_k = test_df.sort_values("churn_probability", ascending=False) \
                   .head(config.TOP_K_AT_RISK)
    top_k.to_csv(Path(config.OUTPUT_DIR).joinpath("top_at_risk.csv"),
                 index=False) \
        if Path(config.OUTPUT_DIR).exists() else None
    Path(config.OUTPUT_DIR).mkdir(exist_ok=True)
    top_k.to_csv(Path(config.OUTPUT_DIR) / "top_at_risk.csv", index=False)
    print(f"\nTop {config.TOP_K_AT_RISK} at-risk customers → "
          f"{config.OUTPUT_DIR}/top_at_risk.csv")

    # ── Feature importance (only available from gbm) ─────────────────────
    importances = pd.DataFrame({
        "feature": feature_cols,
        "importance": gbm.feature_importances_,
    }).sort_values("importance", ascending=False)
    importances.to_csv("data/feature_importance.csv", index=False)

    # ── Save results ─────────────────────────────────────────────────────
    results = {
        "n_train": len(X_train),
        "n_test": len(X_test),
        "test_churn_rate": float(y_test.mean()),
        "best_model": best_name,
        "metrics": {"logistic_regression": m_logit, "lightgbm": m_gbm},
        "confusion_matrix": {
            "true_positive":  int(tp),
            "false_positive": int(fp),
            "false_negative": int(fn),
            "true_negative":  int(tn),
        },
        "top_k": config.TOP_K_AT_RISK,
    }
    with open(Path(config.OUTPUT_DIR) / "results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved → {config.OUTPUT_DIR}/results.json")


if __name__ == "__main__":
    main()
