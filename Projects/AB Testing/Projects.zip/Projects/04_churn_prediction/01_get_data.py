"""
01_get_data.py — Generate synthetic customer data with realistic churn signals.

Features generated:
  - tenure_months       (how long with the company)
  - monthly_charges     (USD/month)
  - total_charges       (lifetime spend)
  - support_tickets     (last 90 days)
  - logins_per_week     (last month average)
  - days_since_login    (recency)
  - has_premium_plan    (0/1)
  - payment_issues      (number of failed payments)

Churn is influenced by these features so the model has signal to learn.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def generate_synthetic_customers() -> pd.DataFrame:
    rng = np.random.default_rng(seed=config.RANDOM_SEED)
    n = config.N_CUSTOMERS

    df = pd.DataFrame({
        "customer_id":     [f"CUST-{i:05d}" for i in range(n)],
        "tenure_months":   rng.integers(1, 73, size=n),
        "monthly_charges": rng.normal(70, 25, size=n).clip(15, 200),
        "support_tickets": rng.poisson(1.5, size=n),
        "logins_per_week": rng.normal(4, 2, size=n).clip(0, 20),
        "days_since_login":rng.exponential(7, size=n).clip(0, 90).astype(int),
        "has_premium_plan":rng.binomial(1, 0.35, size=n),
        "payment_issues":  rng.poisson(0.3, size=n),
    })
    df["total_charges"] = (df["tenure_months"] * df["monthly_charges"]
                           * rng.uniform(0.9, 1.1, size=n)).round(2)

    # Churn probability driven by multiple signals
    logit = (
        -1.5
        + 0.04 * df["days_since_login"]        # disengaged → more likely to churn
        + 0.35 * df["payment_issues"]          # payment problems → churn
        + 0.18 * df["support_tickets"]         # high support load → churn
        - 0.15 * df["logins_per_week"]         # engaged → retain
        - 0.02 * df["tenure_months"]           # tenure → retain
        - 0.7  * df["has_premium_plan"]        # premium → retain
    )
    p_churn = 1 / (1 + np.exp(-logit))
    # Scale so overall churn rate is roughly CHURN_BASE_RATE
    p_churn = p_churn * (config.CHURN_BASE_RATE / p_churn.mean())
    p_churn = p_churn.clip(0, 1)
    df["churned"] = rng.binomial(1, p_churn)

    actual_rate = df["churned"].mean()
    print(f"  → generated {len(df):,} customers, "
          f"{int(df['churned'].sum())} churned ({actual_rate:.1%})")
    return df


def load_user_file(path: str) -> pd.DataFrame:
    print(f"Loading user data from {path} ...")
    df = pd.read_csv(path)
    if config.TARGET_COLUMN not in df.columns:
        raise ValueError(f"Expected target column '{config.TARGET_COLUMN}' in CSV")
    df = df.rename(columns={config.TARGET_COLUMN: "churned"})
    df["churned"] = df["churned"].astype(int)
    print(f"  → loaded {len(df):,} customers")
    return df


def main():
    Path("data").mkdir(exist_ok=True)
    if config.INPUT_FILE:
        df = load_user_file(config.INPUT_FILE)
    else:
        df = generate_synthetic_customers()
    df.to_csv(config.RAW_DATA_PATH, index=False)
    print(f"Saved → {config.RAW_DATA_PATH}")


if __name__ == "__main__":
    main()
