"""
02_clean_prepare.py — Validate, encode, and add a couple of engineered features.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config


def main():
    df = pd.read_csv(config.RAW_DATA_PATH)
    print(f"Loaded {len(df):,} rows")

    # Drop rows with missing target
    df = df.dropna(subset=["churned"]).reset_index(drop=True)

    # Engineered features useful for any customer behavior data
    if "monthly_charges" in df and "tenure_months" in df:
        df["charges_per_tenure"] = df["monthly_charges"] / (df["tenure_months"] + 1)
    if "support_tickets" in df and "tenure_months" in df:
        df["tickets_per_tenure"] = df["support_tickets"] / (df["tenure_months"] + 1)

    # Fill any remaining NaN with column median (numeric) or 0 (categorical)
    for col in df.select_dtypes(include=[np.number]).columns:
        df[col] = df[col].fillna(df[col].median())

    print(f"After cleaning: {len(df):,} rows, {df.shape[1]} columns")
    print(f"Churn rate: {df['churned'].mean():.1%}")

    df.to_csv(config.CLEAN_DATA_PATH, index=False)
    print(f"Saved → {config.CLEAN_DATA_PATH}")


if __name__ == "__main__":
    main()
