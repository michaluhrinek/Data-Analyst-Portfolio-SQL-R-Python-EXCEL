"""Configuration for Project 4 — Churn Prediction"""

# ─── DATA SOURCE ─────────────────────────────────────────────────────────────
USE_SYNTHETIC = True
INPUT_FILE = None
TARGET_COLUMN = "churned"  # name of the 0/1 target in your file

# ─── SYNTHETIC DATA PARAMETERS ───────────────────────────────────────────────
N_CUSTOMERS = 5000
CHURN_BASE_RATE = 0.18   # ≈ 18% of customers actually churn
RANDOM_SEED = 42

# ─── MODEL PARAMETERS ────────────────────────────────────────────────────────
TEST_SIZE = 0.25
TOP_K_AT_RISK = 100      # how many top at-risk customers to surface

# ─── FILE PATHS ──────────────────────────────────────────────────────────────
RAW_DATA_PATH = "data/raw_data.csv"
CLEAN_DATA_PATH = "data/clean_data.csv"
OUTPUT_DIR = "outputs"
