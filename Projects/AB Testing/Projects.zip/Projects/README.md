# Data Science Learning Projects

Five end-to-end projects, one per technique. Each project follows the same skeleton so you can navigate them consistently.

## The five projects

1. **01_hypothesis_testing** — Did this change really make a difference? Uses ECB exchange rate data to compare two time periods statistically.
2. **02_ab_testing** — Which option wins? Simulates an A/B test on a website conversion funnel and analyzes the result properly.
3. **03_revenue_prediction** — How much will this generate? Forecasts retail sales using historical patterns and machine learning.
4. **04_churn_prediction** — Who's about to leave? Predicts customer churn from behavioral signals.
5. **05_marketing_analysis** — Where should we focus? Segmentation, cohort analysis, and channel attribution on synthetic marketing data.

## Standard project skeleton

Every project has the same files in the same order:

```
project_name/
├── README.md           ← What it does, how to run, what to learn
├── requirements.txt    ← Just the packages this project needs
├── config.py           ← Toggle SYNTHETIC vs REAL data, set parameters
├── 01_get_data.py      ← Generates synthetic OR fetches real data
├── 02_clean_prepare.py ← Loading, cleaning, feature engineering
├── 03_analyze.py       ← Statistical analysis / ML core
├── 04_present.py       ← Charts + summary report
├── run_all.py          ← Runs everything end-to-end
├── data/               ← Raw + cleaned data
└── outputs/            ← Charts, reports, model artifacts
```

## How to use a project

```bash
cd 01_hypothesis_testing
pip install -r requirements.txt
python run_all.py
```

Then open the `outputs/` folder to see the report and charts.

## How to use your own data

In `config.py` of each project:

```python
USE_REAL_DATA = True            # toggle synthetic / real
INPUT_FILE = "data/raw.csv"     # path to your own file
```

If your file has different column names, edit the `COLUMN_MAP` dictionary in `02_clean_prepare.py`.

## Suggested order

Do them in order 1 → 5. Each builds intuition for the next:
- Hypothesis testing teaches you the foundation of "is this real or noise?"
- A/B testing is hypothesis testing applied to product decisions
- Revenue & churn prediction introduce supervised ML
- Marketing analysis brings everything together

## Data sources used (when in real mode)

- **ECB Exchange Rates** — https://data.ecb.europa.eu/  (Project 1)
- **UCI Bank Marketing dataset** — https://archive.ics.uci.edu/  (Project 5, optional)

All other projects use synthetic data generation by default so you can run them offline.

## Requirements (overall)

- Python 3.10+
- See each project's `requirements.txt` for specifics
